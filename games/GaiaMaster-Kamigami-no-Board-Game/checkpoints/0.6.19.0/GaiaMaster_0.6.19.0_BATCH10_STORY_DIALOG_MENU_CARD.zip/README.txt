﻿GAIA MASTER VI 0.6.19.0 - BATCH 10
====================================

TRỌNG TÂM
- Cốt truyện / intro được biên tập lại theo chất thần thoại-fantasy.
- Thoại tửu quán và NPC ưu tiên dịch trực tiếp từ tiếng Nhật.
- Menu / prompt được làm rõ, có dấu.
- Tên + mô tả vũ khí / phép / item được đẩy thêm.
- Card sự kiện, Thần, Ma Vương, công trình và hiệu ứng card được Việt hóa mạnh.
- Những dòng đã có vi_full được biên tập fantasy rồi promote nếu vừa field.
- Nếu quá dài: thử bản compact.
- Nếu vẫn quá dài: thử fallback có dấu.

AN TOÀN
- Giữ nguyên %s, %d, %4d, %+3d.
- Font giữ nguyên.
- Intro vẫn loại ký tự "=" từng gây glyph Nhật.
- Ký tự ngoài codepage chỉ hạ riêng về base letter.
- Gate legacy 397/397 vẫn do builder nền kiểm tra.

VĂN PHONG
- NPC đối đầu: ta / ngươi, tỉ thí, chiến lợi.
- Thế giới: Thánh địa, Ma Vương, Tà thần, Thần Thời, Thần Vận.
- Kinh tế/bàn cờ: lãnh địa, lộ phí, quân quỹ khi phù hợp.
- Menu hệ thống vẫn rõ ràng, không cổ hóa quá mức.

CÁCH DÙNG
1. Giải nén ZIP ra folder mới.
2. Chép CLEAN Gaia Master Japan BIN vào cùng folder.
3. Double-click BUILD_GAIA_MASTER_VI_0.6.19.0.cmd
4. Chờ [DONE].
5. Mở CUE 0.6.19.0 vừa sinh ra.

Cần Internet lúc build.
